
"""
FC BESS Sim V5.1 - long-run optimized summary version

Purpose:
- Preserve FC BESS V4.5 control logic:
  grid fullness -> C -> F -> RTC -> actuator
  market price -> signed Opportunity Scale -> RTC -> actuator
  energy-property ledger for R
- Avoid the V4.5 long-run timeout by using a streaming summary loop.
- Does not store a full per-second trace unless --trace-csv is provided.

Default actuator convention:
    positive MW = charge / buy
    negative MW = discharge / sell
    zero MW     = hold
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, List, Optional, Tuple
import argparse
import math
import csv
import time

import numpy as np
import pandas as pd


REQUIRED_COLUMNS = [
    "second",
    "market_price_usd_per_mwh",
    "reserve_requirement_mwh",
    "contract_obligation_status",
    "temperature_status",
    "available_charge_rate_mw",
    "available_discharge_rate_mw",
    "current_grid_load_mw",
    "available_grid_capacity_mw",
    "soc_percent",
]


@dataclass
class BESSConfig:
    capacity_mwh_per_installation: float = 100.0
    max_charge_mw_per_installation: float = 50.0
    max_discharge_mw_per_installation: float = 50.0
    initial_soc_percent_default: float = 50.0
    tick_seconds: int = 1
    price_buffer_count: int = 24
    price_update_seconds: int = 300
    hold_band_fraction: float = 0.05
    round_trip_efficiency: float = 1.0


@dataclass
class RunResult:
    environment: str
    days_requested: int
    bess_installations: int
    ticks: int
    initial_R_mwh_equivalent: float
    final_R_mwh_equivalent: float
    delta_R_mwh_equivalent: float
    gross_energy_property_gain_mwh: float
    gross_energy_property_loss_mwh: float
    net_arbitrage_energy_property_gain_mwh: float
    total_revenue_usd: float
    total_buying_cost_usd: float
    net_profit_usd: float
    energy_bought_mwh: float
    energy_sold_mwh: float
    final_soc_mwh: float
    final_soc_percent: float
    final_market_energy_property_mwh_equivalent: float
    buy_time_seconds: int
    sell_time_seconds: int
    hold_time_seconds: int
    avg_F: float
    min_F: float
    max_F: float
    avg_opportunity: float
    min_opportunity: float
    max_opportunity: float
    runtime_seconds: float


def clamp(x: float, lo: float, hi: float) -> float:
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x


def normalize_status(value: object) -> str:
    return str(value).strip().lower().replace(" ", "_").replace("-", "_")


def temperature_multiplier(status: object) -> float:
    s = normalize_status(status)
    if s == "critical":
        return 0.0
    if s == "warning":
        return 0.5
    return 1.0


def contract_override_opportunity(status: object) -> Optional[float]:
    s = normalize_status(status)
    if s in {"charge_required", "must_buy", "must_charge"}:
        return 1.0
    if s in {"discharge_required", "must_sell", "must_discharge"}:
        return -1.0
    if s in {"hold_reserve", "must_hold", "hold"}:
        return 0.0
    return None


def opportunity_scale(current_price: float, rolling_average_price: float, hold_band_fraction: float) -> float:
    if rolling_average_price <= 0:
        return 0.0
    deviation = (rolling_average_price - current_price) / rolling_average_price
    if abs(deviation) <= hold_band_fraction:
        return 0.0
    excess = (abs(deviation) - hold_band_fraction) / max(1.0 - hold_band_fraction, 1e-9)
    return clamp(math.copysign(excess, deviation), -1.0, 1.0)


def validate_environment(df: pd.DataFrame) -> None:
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required environment columns: {missing}")
    if len(df) < 24:
        raise ValueError("Environment must contain at least 24 rows to initialize the Price Buffer.")


def repeat_or_trim_environment(df: pd.DataFrame, days: int, tick_seconds: int) -> pd.DataFrame:
    target_ticks = int(days * 24 * 60 * 60 / tick_seconds)
    if len(df) == target_ticks:
        out = df
    elif len(df) > target_ticks:
        out = df.iloc[:target_ticks].copy()
        out["second"] = np.arange(len(out), dtype=int) * tick_seconds
    else:
        reps = int(math.ceil(target_ticks / len(df)))
        out = pd.concat([df] * reps, ignore_index=True).iloc[:target_ticks].copy()
        out["second"] = np.arange(len(out), dtype=int) * tick_seconds
    return out


class RollingPriceBuffer:
    def __init__(self, initial_prices: Iterable[float], max_count: int):
        self.max_count = int(max_count)
        self.prices: List[float] = [float(x) for x in initial_prices]
        if len(self.prices) != self.max_count:
            raise ValueError(f"PriceBuffer requires exactly {self.max_count} startup prices.")
        self.sum_prices = float(sum(self.prices))
        self.index = 0

    @property
    def rolling_average(self) -> float:
        return self.sum_prices / self.max_count

    def update_if_due(self, tick_index: int, price: float, update_seconds: int) -> None:
        if tick_index >= self.max_count and tick_index % update_seconds == 0:
            old = self.prices[self.index]
            new = float(price)
            self.prices[self.index] = new
            self.sum_prices += new - old
            self.index = (self.index + 1) % self.max_count


def run_fc_bess_v5_1(
    env_path: str | Path,
    environment_name: str = "",
    days: int = 1,
    bess_installations: int = 1,
    config: BESSConfig = BESSConfig(),
    trace_csv: str | Path | None = None,
) -> Tuple[RunResult, Optional[Path]]:
    start_time = time.time()

    df0 = pd.read_csv(env_path)
    validate_environment(df0)
    df = repeat_or_trim_environment(df0, days=days, tick_seconds=config.tick_seconds)

    capacity_mwh = config.capacity_mwh_per_installation * int(bess_installations)
    max_charge_mw = config.max_charge_mw_per_installation * int(bess_installations)
    max_discharge_mw = config.max_discharge_mw_per_installation * int(bess_installations)

    prices = df["market_price_usd_per_mwh"].astype(float).to_numpy()
    price_buffer = RollingPriceBuffer(prices[: config.price_buffer_count], config.price_buffer_count)

    first_soc = df["soc_percent"].dropna()
    initial_soc_percent = float(first_soc.iloc[0]) if len(first_soc) else config.initial_soc_percent_default

    soc_mwh = capacity_mwh * initial_soc_percent / 100.0
    grid_energy_property_mwh = soc_mwh
    initial_R = soc_mwh + grid_energy_property_mwh

    gross_gain = 0.0
    gross_loss = 0.0
    energy_bought = 0.0
    energy_sold = 0.0
    buy_time = 0
    sell_time = 0
    hold_time = 0
    total_cost = 0.0
    total_revenue = 0.0

    sum_F = 0.0
    min_F = float("inf")
    max_F = float("-inf")
    sum_O = 0.0
    min_O = float("inf")
    max_O = float("-inf")

    dt_hours = config.tick_seconds / 3600.0

    trace_writer = None
    trace_file = None
    trace_handle = None

    if trace_csv:
        trace_file = Path(trace_csv)
        trace_file.parent.mkdir(parents=True, exist_ok=True)
        trace_handle = trace_file.open("w", newline="")
        trace_fields = [
            "second",
            "market_price_usd_per_mwh",
            "rolling_avg_price",
            "opportunity_scale_signed",
            "grid_utilization",
            "R_before_actuation_mwh_equivalent",
            "C_mwh_equivalent",
            "F",
            "action",
            "power_command_mw",
            "soc_mwh",
            "soc_percent",
            "grid_energy_property_mwh",
            "R_after_actuation_mwh_equivalent",
            "delta_R_mwh_equivalent",
            "gross_energy_property_gain_mwh",
            "gross_energy_property_loss_mwh",
            "net_arbitrage_energy_property_gain_mwh",
            "total_revenue_usd",
            "total_buying_cost_usd",
            "net_profit_usd",
            "energy_bought_mwh",
            "energy_sold_mwh",
        ]
        trace_writer = csv.DictWriter(trace_handle, fieldnames=trace_fields)
        trace_writer.writeheader()

    columns = list(df.columns)
    col_index = {c: i for i, c in enumerate(columns)}
    required_idx = {c: col_index[c] for c in REQUIRED_COLUMNS}

    rows_iter = df.itertuples(index=False, name=None)

    for i, row in enumerate(rows_iter):
        current_price = float(row[required_idx["market_price_usd_per_mwh"]])
        price_buffer.update_if_due(i, current_price, config.price_update_seconds)
        rolling_avg_price = price_buffer.rolling_average

        current_R = soc_mwh + grid_energy_property_mwh

        load = float(row[required_idx["current_grid_load_mw"]])
        grid_capacity = float(row[required_idx["available_grid_capacity_mw"]])
        grid_utilization = clamp(load / grid_capacity if grid_capacity > 0 else 1.0, 0.0, 1.0)
        C = grid_utilization * current_R
        F = clamp((current_R - C) / current_R if current_R > 0 else 0.0, 0.0, 1.0)

        reserve_requirement_mwh = max(0.0, float(row[required_idx["reserve_requirement_mwh"]]))
        contract_status = row[required_idx["contract_obligation_status"]]
        temp_status = row[required_idx["temperature_status"]]
        available_charge_rate_mw = max(
            0.0,
            min(max_charge_mw, float(row[required_idx["available_charge_rate_mw"]]) * int(bess_installations)),
        )
        available_discharge_rate_mw = max(
            0.0,
            min(max_discharge_mw, float(row[required_idx["available_discharge_rate_mw"]]) * int(bess_installations)),
        )
        available_room_to_buy_mwh = max(0.0, capacity_mwh - soc_mwh)
        available_energy_to_sell_mwh = max(0.0, soc_mwh - reserve_requirement_mwh)

        O = opportunity_scale(current_price, rolling_avg_price, config.hold_band_fraction)
        forced = contract_override_opportunity(contract_status)
        if forced is not None:
            O = forced

        signed_strength = O * F
        allowed_fraction = abs(signed_strength)
        temp_mult = temperature_multiplier(temp_status)

        if O > 0:
            requested_power = allowed_fraction * available_charge_rate_mw * temp_mult
            power_command_mw = max(0.0, requested_power)
            action = "buy"
        elif O < 0:
            requested_power = allowed_fraction * available_discharge_rate_mw * temp_mult
            power_command_mw = -max(0.0, requested_power)
            action = "sell"
        else:
            power_command_mw = 0.0
            action = "hold"

        energy_this_tick = abs(power_command_mw) * dt_hours

        if power_command_mw > 0:
            battery_property_per_mwh = config.round_trip_efficiency
            grid_spent_per_mwh = max(0.0, battery_property_per_mwh - max(O, 0.0))
            max_buy_by_grid_property = (
                grid_energy_property_mwh / grid_spent_per_mwh if grid_spent_per_mwh > 0 else energy_this_tick
            )
            allowed_energy = min(energy_this_tick, available_room_to_buy_mwh, max_buy_by_grid_property)
            if allowed_energy > 0:
                grid_property_spent = allowed_energy * grid_spent_per_mwh
                battery_property_gained = allowed_energy * battery_property_per_mwh
                soc_mwh += battery_property_gained
                grid_energy_property_mwh -= grid_property_spent
                energy_delta = battery_property_gained - grid_property_spent
                if energy_delta >= 0:
                    gross_gain += energy_delta
                else:
                    gross_loss += abs(energy_delta)
                energy_bought += allowed_energy
                total_cost += allowed_energy * current_price
                buy_time += config.tick_seconds
                power_command_mw = allowed_energy / dt_hours
                action = "buy"
            else:
                power_command_mw = 0.0
                action = "hold"
                hold_time += config.tick_seconds

        elif power_command_mw < 0:
            allowed_energy = min(energy_this_tick, available_energy_to_sell_mwh)
            if allowed_energy > 0:
                battery_property_spent = allowed_energy
                grid_gain_per_mwh = max(0.0, 1.0 + max(-O, 0.0))
                grid_property_gained = allowed_energy * grid_gain_per_mwh
                soc_mwh -= battery_property_spent
                grid_energy_property_mwh += grid_property_gained
                energy_delta = grid_property_gained - battery_property_spent
                if energy_delta >= 0:
                    gross_gain += energy_delta
                else:
                    gross_loss += abs(energy_delta)
                energy_sold += allowed_energy
                total_revenue += allowed_energy * current_price
                sell_time += config.tick_seconds
                power_command_mw = -allowed_energy / dt_hours
                action = "sell"
            else:
                power_command_mw = 0.0
                action = "hold"
                hold_time += config.tick_seconds
        else:
            hold_time += config.tick_seconds

        soc_mwh = clamp(soc_mwh, 0.0, capacity_mwh)
        grid_energy_property_mwh = max(0.0, grid_energy_property_mwh)
        current_R_after = soc_mwh + grid_energy_property_mwh

        sum_F += F
        min_F = min(min_F, F)
        max_F = max(max_F, F)
        sum_O += O
        min_O = min(min_O, O)
        max_O = max(max_O, O)

        if trace_writer is not None:
            second_value = int(row[required_idx["second"]])
            trace_writer.writerow({
                "second": second_value,
                "market_price_usd_per_mwh": current_price,
                "rolling_avg_price": rolling_avg_price,
                "opportunity_scale_signed": O,
                "grid_utilization": grid_utilization,
                "R_before_actuation_mwh_equivalent": current_R,
                "C_mwh_equivalent": C,
                "F": F,
                "action": action,
                "power_command_mw": power_command_mw,
                "soc_mwh": soc_mwh,
                "soc_percent": soc_mwh / capacity_mwh * 100.0 if capacity_mwh else 0.0,
                "grid_energy_property_mwh": grid_energy_property_mwh,
                "R_after_actuation_mwh_equivalent": current_R_after,
                "delta_R_mwh_equivalent": current_R_after - initial_R,
                "gross_energy_property_gain_mwh": gross_gain,
                "gross_energy_property_loss_mwh": gross_loss,
                "net_arbitrage_energy_property_gain_mwh": gross_gain - gross_loss,
                "total_revenue_usd": total_revenue,
                "total_buying_cost_usd": total_cost,
                "net_profit_usd": total_revenue - total_cost,
                "energy_bought_mwh": energy_bought,
                "energy_sold_mwh": energy_sold,
            })

    if trace_handle is not None:
        trace_handle.close()

    ticks = len(df)
    final_R = soc_mwh + grid_energy_property_mwh
    runtime_seconds = time.time() - start_time

    result = RunResult(
        environment=environment_name or Path(env_path).stem,
        days_requested=days,
        bess_installations=int(bess_installations),
        ticks=ticks,
        initial_R_mwh_equivalent=initial_R,
        final_R_mwh_equivalent=final_R,
        delta_R_mwh_equivalent=final_R - initial_R,
        gross_energy_property_gain_mwh=gross_gain,
        gross_energy_property_loss_mwh=gross_loss,
        net_arbitrage_energy_property_gain_mwh=gross_gain - gross_loss,
        total_revenue_usd=total_revenue,
        total_buying_cost_usd=total_cost,
        net_profit_usd=total_revenue - total_cost,
        energy_bought_mwh=energy_bought,
        energy_sold_mwh=energy_sold,
        final_soc_mwh=soc_mwh,
        final_soc_percent=soc_mwh / capacity_mwh * 100.0 if capacity_mwh else 0.0,
        final_market_energy_property_mwh_equivalent=grid_energy_property_mwh,
        buy_time_seconds=buy_time,
        sell_time_seconds=sell_time,
        hold_time_seconds=hold_time,
        avg_F=sum_F / ticks if ticks else 0.0,
        min_F=min_F if ticks else 0.0,
        max_F=max_F if ticks else 0.0,
        avg_opportunity=sum_O / ticks if ticks else 0.0,
        min_opportunity=min_O if ticks else 0.0,
        max_opportunity=max_O if ticks else 0.0,
        runtime_seconds=runtime_seconds,
    )
    return result, trace_file


def main() -> None:
    parser = argparse.ArgumentParser(description="Run FC BESS Sim V5.1 long-run optimized")
    parser.add_argument("--env", type=str, required=True, help="Path to environment CSV.")
    parser.add_argument("--environment-name", type=str, default="", help="Name for the run.")
    parser.add_argument("--days", type=int, default=1, choices=[1, 7, 30])
    parser.add_argument("--bess", type=int, default=1, choices=[1, 5, 25, 100])
    parser.add_argument("--hold-band", type=float, default=0.05, help="Hold band fraction, e.g. 0.02 for ±2%.")
    parser.add_argument("--trace-csv", type=str, default="", help="Optional trace CSV output path.")
    parser.add_argument("--summary-csv", type=str, default="", help="Optional summary CSV output path.")
    args = parser.parse_args()

    cfg = BESSConfig(hold_band_fraction=args.hold_band)
    result, trace_path = run_fc_bess_v5_1(
        env_path=args.env,
        environment_name=args.environment_name or Path(args.env).stem,
        days=args.days,
        bess_installations=args.bess,
        config=cfg,
        trace_csv=args.trace_csv or None,
    )

    out = pd.DataFrame([asdict(result)])
    if args.summary_csv:
        Path(args.summary_csv).parent.mkdir(parents=True, exist_ok=True)
        out.to_csv(args.summary_csv, index=False)
    print(out.to_string(index=False))
    if trace_path:
        print(f"trace_csv {trace_path}")


if __name__ == "__main__":
    main()
